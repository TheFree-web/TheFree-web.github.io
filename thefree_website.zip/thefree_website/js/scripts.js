// Voor toekomstige interactieve functies
console.log("The Free website loaded");

